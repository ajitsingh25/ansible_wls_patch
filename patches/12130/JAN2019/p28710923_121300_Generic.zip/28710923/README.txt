===============================
Patch Set Update (PSU) for Bug: 28710923
===============================

Date:  Tue Nov 13 12:53:32 2018
---------------------------------
Platform Patch for : Generic
Product Patched : ORACLE WEBLOGIC SERVER
Product Version      : 12.1.3.0.0


This document describes how to install the interim patch for
bug #  28710923. It includes the following sections:

	Section 1, "Zero Downtime Patching"

 	Section 2, "Prerequisites"

	Section 3, "Pre-Installation Instructions"

	Section 4, "Installation Instructions"

	Section 5, "Post-Installation Instructions"

	Section 6, "Deinstallation Instructions"

	Section 7, "Post Deinstallation Instructions"

	Section 8, "Bugs Fixed by This Patch"

        Section 9, "Known Issues"


 
1 Zero Downtime Patching
------------------------------
This patch has been marked as eligible for Zero Downtime Patching. 

With Zero Downtime Patching, a Patch can be applied to a system in a manner
that does not incur any downtime. This ensures that the system can remain
available and functioning during the patching process. Certain
pre-requisites, however, must be met before the patch can be applied.

For more information, consult the My Oracle Support MOS Note: 1942159.1

 

2 Prerequisites
----------------
Ensure that you meet the following requirements before you install or
deinstall the patch:

1. Before applying the non-mandatory patches, ensure that you have the
exact symptoms described in the bug.


2. Update Java SE (JDK/JRE):

For users of Oracle JDKs and JVMs, we strongly recommend applying the latest
Java Critical Patch Updates (CPUs) as soon as they are released. Refer to the
following for further information:

Doc ID 1506916.1 Obtaining Java SE (JDK/JRE) for Oracle Fusion Middleware Products
https://support.oracle.com/rs?type=doc&id=1506916.1


3. Oracle recommends that all customers be on the latest version of OPatch for
their release. Download the latest version of OPatch 13.2.x via My Oracle
Support Patch 6880880. (Choose 13.2.0.0.0 or "OUI NextGen 13.2")

Patch: p6880880_132000_Generic.zip

Review the following for more information :
Doc ID 1587524.1, "Using OPatch 13.1 for Oracle Fusion Middleware 12c (12.1.2+)"
https://support.oracle.com/rs?type=doc&id=1587524.1

For Oracle Fusion Middleware OPatch usage, refer to the URL below which
redirects to the latest FMW 12c document:
"Oracle Fusion Middleware Patching With OPatch"
http://www.oracle.com/pls/topic/lookup?ctx=fmw121x00&id=OPATC


4. Verify the OUI Inventory.
OPatch needs access to a valid OUI inventory to apply patches.

Note: This needs the ORACLE_HOME to be set(refer section "2. Pre-Installation Instructions")
prior to run the below commands:

Validate the OUI inventory with the following commands:

$ opatch lsinventory -jre $ORACLE_HOME/jdk/jre

Note:
All OPatch commands should be run with -jre option.
Make sure the JDK version you use is the certified version for your product.

If the command errors out, contact Oracle Support and work to validate
and verify the inventory setup before proceeding.


5. Confirm the executables appear in your system PATH:

The patching process will use the unzip and the OPatch executables. After
setting the ORACLE_HOME environment, confirm if the following executables
exist, before proceeding to the next step:

- opatch
- unzip

If either of these executables do not show in the PATH, correct the
problem before proceeding.


6. Create a location for storing the unzipped patch: 

This location will be referred to later in the document as PATCH_TOP.

NOTE: On WINDOWS, the preferred location is the drive root directory.
For example, "C:\PATCH_TOP" and avoid choosing locations like,
"C:\Documents and Settings\username\PATCH_TOP".
This is necessary due to the 256 characters limitation on windows
platform.

3 Pre-Installation Instructions
-------------------------------

1. Set the ORACLE_HOME environment variable to the directory where you have installed ORACLE WEBLOGIC SERVER.




4 Installation Instructions
---------------------------

1. Unzip the patch zip file into the PATCH_TOP.

$ unzip -d PATCH_TOP p28710923_121300_Generic.zip

NOTE: On WINDOWS, the unzip command has a limitation of 256 characters in the path name.
If you encounter this, please use an alternate ZIP utility like 7-Zip to unzip the patch.

For example: To unzip using 7-zip, run the command:
"c:\Program Files\7-Zip\7z.exe" x  p28710923_121300_Generic.zip

2. Set your current directory to the directory where the patch is located.

$ cd PATCH_TOP/28710923

3. Run OPatch to apply the patch.

$ opatch apply


Note:
-----
When OPatch starts, it validates the patch and makes sure that there are no
conflicts with the software already installed in the ORACLE_HOME.

In case of opatch conflict, you will see a warning message similar to the one mentioned below:

Interim Patch XXXX has Conflict with patch(es) [ YYYY ] in OH ...
Conflict patches: YYYY
Patch(es) YYYY conflict with the patch currently being installed (XXXX).
If you continue, patch(es) YYYY will be rolled back and the new patch (XXXX) will be installed.

If a merge of the new patch (XXXX) and the conflicting patch(es) ( YYYY) is required,contact Oracle Support Services and request a Merged patch.

Do you want to proceed? [y|n]
n

You must stop the patch installation and contact oracle support on how to proceed.

5 Post-Installation Instructions
---------------------------------


Start all servers (AdminServer and all Managed server(s)).


6 Deinstallation Instructions
------------------------------

If you experience any problems after installing this patch, remove the patch as
follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any)
when deinstalling a patch.
This includes setting up any environment variables like ORACLE_HOME and
verifying the OUI inventory before deinstalling.

2. Change to the directory where the patch was unzipped.

$ cd PATCH_TOP/28710923

3. Run OPatch to deinstall the patch.

$ opatch rollback -id  28710923

7 Post Deinstallation Instructions
-----------------------------------
Restart all servers (AdminServer and all Managed server(s)).

This is necessary to redeploy the original applications and bring the
environment back to it's original state.

8 Bugs Fixed by This Patch
--------------------------
18538501 An InvalidTargetException occurs when deploying a simple application to the cluster of a newly created domain.
18746515 D.efault error-page from servlet 3.0 sending merging response of 404 error code. remoteDRT_webappcheckintest failing after the fix of fix of BUG18746515
17394051 ClassLoader leak happens on redeployment if ChangeAwareClassLoader is referenced from ClassTableEntry and it's retained by BubblingAbbrever. WebLogic classloader objects are sometimes obtained by BubblingAbbrever it causes classloader leak.
19668883 When remote JMX is enabled it causes high CPU utilization and when it is disabled CPU utilization is normal.
18376812 The <cookie-config> settings in the web.xml file are not being honored when you remove the <cookie-config> section in the weblogic.xml file.
21746415 MAVEN PLUGIN FAILS TO EXECUTE GOAL UNDER PLUGIN COMPONENT
20333386 WLS lacks privileged block while connecting to server during session replication.
20720853 Thread contention was seen during very high load.
22498352 CVE-2016-0638
14236278 CVE-2016-0675
21081720 EJB in MDB does not work when beans.xml is present.
20585084 Redundant enormous loops during deployment when using War including a lot of EJBs.
21522926 WebLogic http sessions not cleared after max inactive interval when websocket connections are abruptly closed.
23099318 CVE-2017-3506
22910817 Change the default for restoring version record.
23063611 NPE in SERVLETRESPONSEIMPL.SETSESSIONCOOKIE in XA STRESS test.
19472793 Sometimes, socket processing is unstable under DevPollSocketMuxer and async HttpClient request.
20692185 ELF(i.e Extended Log File) header will be not added after rotation of access.log.
22749253 A WebLogic JMS client intermittently generates a java.lang.AssertionError: Restarting a consumer that was not stopped, when consuming from a durable shared subscription. Messages can subsequently accumulate on the subscription if the subscriber is not recreated.
22107941 There is an issue with client identify management under parallel condition. The java.lang.IllegalStateException is thrown.
24802574 Fixed an issue where it was not possible to have a SAFAgent as a target of a subdeployment in WLST offline
19175526 Fixed an issue where a 403 error would occur when accessing an app deployed with "upload your file(s)" link
25029531 Application breaks after applying October 2016 PSU due to multipart form-data.
21347054 Fixed an issue where the CDI interceptors of a deployed application were being called twice
25695948 Fixed an issue where it was not possible to reset the offline collection fields to none/empty
18854885 Fixed an issue with MDB durable subscriber not reconnecting after manual migration
24469063 Fixed an issue where if the JNDI tree lookup is locked with a Security Policy granting access to User with Admin Role, a user with Monitor role was unable to access the Servers page
25720769 CVE-2017-10137
22690676 Fixed an issue where an EJB deployment was failing with a StringIndexOutOfBoundsException
20952741 Fixed an issue where HttpURLConnection.getErrorStream() was returning null for a 401 response
26985581 Fixed an issue where a  java.lang.StringIndexOutOfBoundsException can occur after applying the 171017 PSU
27948303 CVE-2018-2893
28043040 CVE-2018-3197
28375173 CVE-2018-3245
26624375 NODEMANAGER MEMORY LEAK ON SSL HANDSHAKE FAILURES
28313163 HTTP SESSION OBJECTS DOESN'T ADHER SESSION TIMEOUT WHEN CLIENT TERMINATES REQUES
19730967 The system property weblogic.data.canTransferAnyFile did not allow some files to be transferred, but now will allow any file to be transferred. 
18727635 An RMIError occurs when the applet client sets the system property.
18305935 JTA JDBC TLOG flush I/O failures are prematurely reported as fatal. 
18428696 References of EJNGEN to SUN.MIRROR.APT are unavailable in JDK8.
18722098 If a timer is created in PostConstruct call of singleton session bean using EJB clustered timer, NullPointerException is thrown.
19080525 Node Manager fails to restart a WebLogic Server process due to a FAILED_NOT_RESTARTABLE error occurring when WebLogic Server fails to start up.
19556868 Under certain circumstances, when using a JMS thin client, the following exception occurs: NoClassDefFoundError: weblogic/management/commandline/tools/AdminToolHelper
20266379 There is an issue with the seconds-to-trust-an-idle-connection functionality.
19973098 For samples javaee6\jca\stockTransaction, after you run 'ant clean build deploy', at the deploy phase, an exception occurs due to which the .war can't deploy successfully.
18082758 Unable to access the WSDL for the Web Service because it is protected.
19917893 No message in logs when WorkManager reaches max capacity constraint.
19705162 HeuristicHazard exceptions while messages are forwarded to other UDD members.
21069524 Fix for bug 21069524
20613957 If a Web service with stateless EJB is deployed, it is unable to access the WSDL.
18945422 Restart service job fails intermittently because getting a WLS server status sometimes fails due to AssertionError.
20229977 WLS lacks privileged blocked at weblogic.application.io.MergedDescriptorFinder.
22175246 Fix for bug 22175246
19467894 Resource pool hitting max capacity on unexpected exceptions from the adapter layer. 
18144979 request.getParameterMap() or request.getParameter()returns parameters not correctly decoded.
20226151 "JSP_SERVLET"was deleted when the server was stopped using stopManagedweblogic script.
18559995 Sets the RJVM's user credentials when creating outbound requests
23640078 Fix for inactive connection timeout does not work in WLS12.1.3, associated tests are failing.
22900750 Resolved issue with getting default user password.
22836462 System property added to allow a user to restore the version record to a JDBC Store when it is missing.
23099223 CVE-2016-3510
23342794 Fixed an issue where static flash resources were not being loaded
20430490 The error Servlet that handled errors in WebApp, did not have access to classes in WebApp.
26144830 CVE-2017-10352
25590885 Disabled SMTP notification causes server to start in Admin state.
25955347 Fixed an issue where BEA-149265 J2EE:160241 Error occurs with resource injection in EJB
22746640 Fixed an issue where Unit-Of-Work messages arriving after the Incomplete Work Expiration Timer has expired were left pending in the queue
25439226 Fixed an issue where random managed servers would show as not reachable in the console
26885274 Fixed an issue where the predicates of the default providers were not being displayed
26769768 CVE-2015-7940
18412312 Fixed nodemanager to restart managed server that is shut down due to overload protection
25993295 CVE-2013-1768
27445260 CVE-2018-2935
28375702 CVE-2018-3246
28110087 CVE-2019-2418
28626991 CVE-2019-2452
18276961 The default error-page is not working in WebLogic Server.
19533331 CDI does not consider all superclasses and interfaces of an EJB when processing EJBs.
18922324 A simple Web application can be deployed when the JACC provider is enabled. The same Web application is not deployed properly when packaged in the same EAR file.
19942900 There is a regression issue that does not allow the Deployer role to deploy applications. 
18485034 Fixed an issue where the last directory in the path specified was getting stripped off when creating JMS FileStores
19339238 bufferedReader hangs when HTTP POST uses chunked transfer encoding.
19500276 EJB in MDB does not work when beans.xml is exist.
19234430 Some of the node manager properties could not be set using WLST commands in offline mode.
20205647 The TenantServletFilter prevented the OWSM authentication policy enforcement; this has been fixed
19585666 Administration port for each dynamic server in a dynamic cluster is not calculated and assigned through Server template.
20169972 The first time a web application is deployed in the production mode, it runs without issues, but once the web application is de-activated, and re-activated from the Admin console, it returns the HTTP Code '500'.
19917991 When the adminserver is down, a managed server on a different host starts up correctly in MSI mode. However, when it tries to start previously deployed applications, it tries to download them again from adminserver which fails. This causes the managed server to go into ADMIN mode.
20906638 CVE-2015-2623
19828316 Fixed an issue where the @POSTCONSTRUCT annotation was ignored in pojo jax-ws when CDI is enabled
19879223 Locale changes are not properly detected as changes to the browser's Locale is not reflected properly in request.getLocale value.
19212729 A NullPointException is thrown when running sample servlet asyncContext complete is called right after async start and the request is occurs.
22247869 Fix for bug 22247869
20758488 Bundle defined at <wl-extension:button-bar> or <wl-extension:button-bar > level, is not taken into consideration in an Admin Console Extension
22200449 Fix for bug 22200449
22200491 CVE-2016-0572
22200594 CVE-2016-0574
20246732 Fixed a case where a MultiDataSource with RAC LLR DSes failed to boot if all DSes were not up.
19463153 Management exception is thrown while activating the changes after setting the custom cluster configuration file.
22249331 When running with the 12.x database driver, service names were not being handled correctly so up/down events were not received. This has been corrected.
21964759 Fixed a few cases where a leaked pool connection was not retracted via the inactive connection timeout.
22486599 Fixes repeated BEA-000192 "A running server was not found to host Timer Master" messages
22860104 Unable to login to console with monitor role user. 
21549018 Fixed a memory leak in weblogic.wsee.jaxws.owsm.wsdldefinitionfeature
19150123 Fixed a case where a hanging application XA DBMS call could block system threads from aborting the transaction.
24305841 CVE-2016-5601
23103220 CVE-2016-5535
24750930 Tracking bug to consume JRF Web services fixes for 22551755 into WLS PSUs.
20717353 When a Servlet is invoked and abruptly the request ends. A ProtocolException should be thrown. However, an NPE error is thrown.
18597348 Fixed an issue where a versioned EJB app, after closing a foreign JMS session, could corrupt the clustered JNDI tree
21562338 Fixed an issue where a Connection.isClosed() call returned false when the real connection had been closed
18387934 Fixed an issue where log output was not occurring during server migration
23304470 Fixed an issue where a stuck thread could occur at weblogic.cluster.replication.replicationmanager
26806438 Fixed a NullPointerException condition that may occur when trying to activate an application
27416586 Fixed a WLST performance issue in assigning JMS resources to Cluster after applying the 171017 PSU
26439373 CVE-2017-5645
20020455 CVE-2018-2902
26353793 CVE-2019-2398
19287842 CVE-2013-2186
18589879 A no-test multi data source will automatically re-use a manual.
19907066 CVE-2014-3566
18718889 Error seen when replacing a session object which is serializable to another object that is non-serializable.
18753794 Accessing an external Web resource is very slow.
19988824 CVE-2015-0482
19265688 Queue forwarding sometimes forwards to ineligible members.
18289179 max-open-sock-count cannot be changed dynamically if it is turned on or turned off.
19883023 Annotation scan takes longer time during Application deployment for customer.
21107126 Fix for bug 21107126
19576633 CVE-2016-5488
20323632 "Tried all: '1' addresses, but could not connect over HTTP to server" message seen when accessing /consolehelp on a system fronted by OHS.
19351700 On WLS 12.1.3, Japanese is not used in WLS Server log (e.g. <wls-server-name>.log) and WLS Standard out (e.g. <wls-server-name>.out) even though an environment variable is set as LANG=ja_JP.UTF-8.
21169554 There is a configuration issue during FA preflight generation.
19874466 NULLPOINTEREXCEPTION occurs if CREATECALENDARTIMER is used in CLUSTER SETUP.
19703527 WebLogic server is unable to start with EM application as a scan is performed and if there are any corrupted dead code or classes in the existing application, the deployment fails.
21252292 NMSERVERSTATUS sometimes overrides SERVERMONITOR STATEINFO as nmServerStatus shows incorrect state of FORCE_SHUTTING_DOWN after finishing WLS process.
21516492 CVE-2014-0107
21615827 CVE-2016-0464
22339918 CVE-2016-0638
20786128 Unable to override the policy under domain runtime mbean.
20672949 Deployment plan does not always work for virtual dir replacement
20907322 Auto-ONS was not functioning correctly. This has been corrected.
22574362 Getting Stuck Thread when loop to retry for consecutive unexpected exception in the MessagePoller.
21836275 Optionally reduce JDBC Store connection usage to 1 per Store.
21519519 CVE-2016-0688
18123824 Memory leak observed when using weblogic deployment API in weblogic.management.deploy.DeploymentTaskRuntime
19775778 If ListenAddress in custom network channels is null, ListenAddress is not generated from NodeManager's ListenAddress. It's different from default channel's behavior.
22586217 Fixed an issue where the presence of / before the ?WSDL at the end of a URL was not recognizing the webservice
21647599 Destroying an app-scoped work manager property does not work 
22550116 Poor JDBC Store performance when CONN CACHING POLICY=NONE
22987229 Internal CDI handling is called even when JSP does not relate to CDI.
20157787 weblogic.net.HTTPURLConnection with Connection and Read timouts set is used to connect over Proxy. The connection does not timeout. 
21119215 JACC Policy is not setup when calling EJB from Servlet.init in same EAR.
23326877 The error ORA-01017: invalid username/password occurs while trying to change the password for data source.
25164167 Though WebLogic Server supports more than one WLDF module targeted to the same server/cluster, an error occurs when trying to target the second (and subsequent) WLDF modules.
24341200 Fixed an issue where pending tasks were not being processed even though there were idle threads available
25059150 CVE-2017-3531
24837293 Fixed an issue where ChangeAwareClassLoader.getResources() was returning different content from ChangeAwareClassLoader.getResource() result
20774032 Fixed an issue where a servlet would fail with an IOException
25205507 Fixed an issue where a partial redeployment of a webservice app was failing with a FileNotFoundException
26596622 Fixed a content-length exception that was occurring with static flash resources
25917709 Fixed an issue where cmo.getmachines was not showing unix machines
26044754 CVE-2017-10336
26632886 Fixed an issue where JTA JDBC TLOG Flush I/O failures were being prematurely determined to be fatal
26608537 CVE-2018-2628
27565682 Fixed an issue that would prevent the EmbeddedServer to start
17905354 Fix for bug 17905354
19033547 A problem occurs in a configuration with a WebLogic Server Active GridLink data source with FAN and AC both enabled working with a RAC cluster. When the public network interface fails, connections that are reserved by the application are not aborted. This can cause the application to hang waiting for a response on the connection.
19459949 There is an issue where affinity is specified but ignored.
18671042 In servlet or EJB application code, calls to javax.security.jacc.PolicyContext.getContext() should return policy context data and not null when the application is running and JACC has been enabled.
18729264 There is an issue with the JDT shipped with WebLogic Server. 
19170125 SAML Identity provider did not process JMS developed using SOAP.
20162146 Fixed an issue where a webservice with a JMSTransport application is deployed on one server and JMS resources were deployed on another, the durable subscribers were created with different names each time the application was restarted
19852007 The Administration Server may hang during startup when Node Manager is configured in a WebLogic domain and the Managed Server(s) is unreachable.
19268444 The following error occurs when both the tag library and the JSP file using the tags are contained inside a JAR file: No tag library could be found with this URI.
19299358 The problem deals with an EJB asynchorous call throwing an exception.  One-way calls are prohibited when a transaction is associated with the calling thread.
19425078 Logging the STRESS:WLS:EXCEPTION exception is delayed when ServletRequest.getPart() or getParts() is invoked.
20062321 Intermittent 500 errors resulting from: ILLEGALSTATEEXCEPTION: HTTP SESSION IS INVALIDATION. 
21039390 The deployment of the second stand-alone multi-source is fixed by deploying multiple MultiDatasources at the application level.
21083766 When calling different modules, JACC Security Context does not push and pop in PolicyContext.
20197139 Fixed an AssertionError that that was occurring during an EJB's initialization with CDI
19689036 Timer EJB will stop when timer expiration is success and previous timer expiration is failed.
21545042 12c can not solve ambiguous ejb-link in case multiple same ejb-name exists in same application.
21294990 The server returns http 413 but it hangs with the client when the client posts data over the defined "Max Post Size" value.
21225816 Fixed an issue where a JMS queue name was being duplicated causing the reconfig wizard to fail
22829635 Timer stops after TimerMaster migration error.
22383225 The application staging mode and plant staging mode should be independent.
22850769 RMI timeout does not work if it's specified on hash table of InitialContext.
19150684 CONCURRENTMODIFICATIONEXCEPTION while iterations through results of work Manger.
18974055 Automatic Service Migration (ASM) can loop if the service start time is larger than the cluster heartbeat timeout.
21189073 Application runtime state is intermittently returning unexpected results.
23555480 The httpclusterservlet incorrectly handle exceptions while flushing chunked data.
22261241 When using wldeploy task to deploy application on a JACC enabled WebLogic Server, the error NoClassDefFoundError: Could not initialize class weblogic.utils.ClassFilter was displayed.
24399682 Fixed an issue where javax.wsdl classes were not being loaded from a web application
19549507 Access.log was not getting updated after managed server was suspended and restarted.
20207088 Fixed an issue where getUserPrincipal() was returning null after the user was successfully authenticated
21562704 Allow a server to boot even if the diagnostic store could not be opened
25577947 CVE-2017-10123
24618043 Fixed an issue where a deadlock occurred on an AGL datasource during a DB failover
24376591 Fixed a NullPointerException that occurred in stress testing
18746053 Fixed an OutOfMemory condition that occurred in stress testing
21270142 Fixed an issue with programming context propagation not working with asynchronous EJB
26038824 Fixed an issue where an exploded GAR file deployment would stop working after applying PSU 12.1.3.0.170117
19763916 CVE-2017-10152
27111664 Fixed an issue with the WSDLReader
28409586 CVE-2018-3252
28481582 Fix for Bug 22690676
28594324 PERF PROD HUGE TIME SPENT IN WEBLOGIC.SECURITY.ACL.INTERNAL.AUTHENTICATEDSUBJECT
19066738 When a NIO socket reaches timeout, socket.write() causes a CloseChannelException error instead of a SocketException error. In addition, if WebLogic Server is launched with - Dweblogic.GatheredWritesEnabled=true, thread will hang on select().
20206879 CVE-2015-4744
20080751 The durable subscriber is not deleted on undeploying a dynamic EJB module.
20814890 Fix for bug 20814890
18836900 WebLogic hangs for 40 minutes while starting up as it spends some time in deploying one application that depends on another shared library.
19953516 Activation process timing out while updating the custom certificate on Admin server and Managed server with all the servers are listening on SSL listenport and are running.
20969389 Fixed an issue where a domain upgrade would fail if the JMS filestore name was changed in the config wizard when the domain was created
19565095 Creating a domain using WLST commands resulted in incorrect JMS server name in most of the invocations.
20952475 Fixed an issue where the custom decurity element would disappear after extending the WLS domain
20721340 Need for early making of pool connections has been removed when EM asks for data about the datasource.
19477196 Application continuity on a JTS or XA connection has been fixed.
22200523 CVE-2016-0573
21129379 WebLogic 12c uses virtual IP-ADDR instead of primary IP-ADDR for T3S
16815912 Producer receives InvalidDestinationException after SAF Agent migration.
21603584 PersistentUnit annotation in SingletonBean does not work
20419243 Interceptors are not called on partition restart after its shutdown
20080046 Wrong number of consumers if custom work manager is used as dispatch policy for a MDB deployed as versioned application.
20311530 NPE when destroying instance of MessageDriven Bean (MDB).
20128089 This fix enables the default host name verifier in WebLogic to process wild-card DNS names contained in the SSL certificate's SAN extension.
20739167 Fixed an issue where a NullPointerException is encountered when trying to access application cache from console.
23107300 CVE-2016-3586
20736912 Resolved issue with invalidated sessions
20193085 The error javax.naming.NameNotFoundException occurred while restarting WebLogic Server after deploying shared EE libraries.
22901740 Deadlock around java.lang.classloader.getclassloadinglock.
22950801 weblogic.wsee.deploy.AppDeploymentExtensionFactory fails to prepare the modules for redeployment.
22541225 WLST does a lookup of url and puts IP in HTTP header host field instead.
22378134 STRESS:Intermittent store health issue in xa stress test when using JDBC Store.
23735210 JMX connection over IIOP broken on SRC103600FABP with JDK6 and 7.
24522430 WLS bug for inclusion of CIE bug fix
23733891 CVE-2017-3248
22836557 CVE-2015-7501
23004029 CVE-2016-5531
23223461 CVE-2016-3551
25192229 When configuring Watches and Notifications in offline mode, while creating the domain, the generated WLDFSystemModule XML file is incorrect.
21158132 There was an issue in the com.tangosol.net.CacheFactory.getCache leading to an increased memory and CPU consumption. 
16956849 Fixed an issue where an OutOfMemory error would occur when stdout was redirected to the server log
25497443 Error 160241 occurs when resource injection exists in EJB.
25118289 Fixed an issue where WebLogic clustering was not working with IIOP protocol
21902034 Fixed an issue where a connection reset with data still in the response buffer would cause socket leaks
26589850 Fixed an issue wherein domainruntime.getserverruntime() would time out on a slow network
26797049 Correct a patch issue discovered in QA
26861216 ISSUES IN VERIFYING THE FIX FOR THE BUG 26630389
24818026 CVE-2017-10271
26547016 CVE-2018-2625
27947832 Fixed an issue where javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING wasn't being properly propagated in WSDLReader.
27819370 CVE-2018-2987
18968900 CVE-2014-6534
18859387 Fix for bug 18859387
19287874 CVE-2013-2186
20523619 Calling a ServerRuntime from an external JMX client or the WebLogic Server Administration Console and starting a Managed Server concurrently may display all applications of the Managed Server in the NEW state with a failed health check.
18432174 Excessive javax.transaction.SystemException errors are logged during a graceful shutdown when JDBC TLog is configured. 
18481239 Declaring the onMessage() method in the super interface of the message listener type interface causes a NoSuchMethodError.
18912482 A java.lang.ClassNotFoundException error occurs when looking up a generic EJB.
17889922 @JMSTRANSPORTSERVICE ignores JNDIURL - always uses LOCAL.
18466848 Not able to target a subdeployment once JMS resource has been created.
19001915 CDI injected principal not updated after calling HTTPSERVLETREQUEST#AUT.
20758863 T3S connection fails to java service OPC domains using WLTHINT3CLIENT T3S connection fails to java service OPC domains using WLTHINT3CLIENT.
19928803 Key files created in WLST Directory are deleted automatically.
17702917 AUTOKILLIFFAILED does not work when server health state is failed because the Restart-in-place option is unable to execute with manual migration configuration.
21561271 When AQJMS as the JMS provider for MDB in sync mode, allow MDB container to use MessageConsumer.receiveNoWait() to optimize AQJMS dequeue performance.
20087183 CDI injection into custom ConstraintValidator impls works when the binding of the ValidatorFactory in the ApplicationContext during deployment for JSF Applications is disabled.
19263075 When an instance down event occurs, WLS will not take any database action the connection except to close it.
19986568 JSP Compilation error when tag file contains recursion.The error happens when tag file is recompiled after a change to tag file. Duplicate member variables and setter and getter methods for JspContext generated. 
20044804 Unable to make outbound ssl async call when connection timeout is set.
22599178 CVE-2016-3499
22097019 WebApp URIs are now encoded.
20629733 Fixed an issue where UnsupportedOperationException is thrown via ApplicationAccess.getApplicationIdFromJndi
22540656 Fixed an issue where TNS-style connect descriptors were not being recognized as they are in WLST online
21834255 SOAEDGE12: WSMPM JDBC transaction log unrecoverable with RAC DB restart
18438079 Session Leak - Sessions are not being destroyed after session timeout
23732201 Fix for bug 23732201
25317743 A java.lang.NullPointerException error occurs when server calls an RMI object on a client.
26144926 Fixed an issue where the JACC policy was not set up correctly when calling an EJB from servlet.init
25534314 Removed unused CAs from DemoTrust
24533963 CVE-2013-2027
21652727 Removed unused CAs from DemoTrust
19926398 Fixed an issue where WLS acting as a client doesnt support SNI
21241854 Fixed an issue where a multi data source failback/failover callback handler was not being called
20047315 Fixed an issue where an unnecessary wrapper pool shutdown was being called on the connection exception listener due to transaction timeout
25743005 CVE-2017-10147
25174732 Fixed an issue where the managed server could not be restarted where an IIOP application is deployed
25750303 Fixed an issue where fluctuation in the network connection between the admin and managed server could cause a permanent disconnect between the two
27117282 Fixed an issue where certgen was failing with jdk8 cpu (180161, b04, b05, b06)
26835012 Fixed a deadlock condition with MBeanServerConnectionManager 
23049601 Fixed several issues with server to server jmx resiliency 
27234961 Improve performance in bean creation to reduce stuck threads when database is slow or down
18691894 CVE-2014-0114
17012341 A DRCP problem causes Closed Statement and Closed Resultset errors.
18964349 There is an issue with stuck threads waiting for a response after an execute request fails with an IllegalStateException error.
17721032 A Managed Server fails to start with a IndexOutOfBoundsException error. 
18806464 When a webservice with JMSTransport application is deployed on Server A and JMS Resources configured on a different server, gives null pointer exceptions.This is fixed now.
16562029 After running java weblogic.appmerge -verbose -output merged.ear -plan MyEJBApp\plan\plan.xml MyEJBApp\app\MyEJBEAR.ear <jta-data-source>jdbc/myds</jta-data-source> in persistence.xml does not change and only <display-name>MyEjbNewName</display-name> in ejb-jar.xml is changed.
19422493 ClassCastException seen when storing a Handle to an EJBObject as a session attribute and reading it back with casting back to Handle.
19297004 Work manager name shows (no value specified) after its creation.
20798352 The HTTP client tries to connect destination server directly if HTTPS connection is opened with explicit proxy object and proxy is unavailable.
20471785 ApplicationAccess.digOutCurrentApplicationId fails to get application and throws UnsupportedOperationException if it's called from transaction after the Completion callback.
20985893 Fix for bug 20985893
19936917 weblogic.workarea.WorkContextLocalMap.copyThreadContexts() causes a ConcurrentModificationException error.
21756751 Fix for bug 21756751
19865550 An error Unsupported Multi Datasource occurred while upgrading to WebLogic Server 12.1.3.
21495475 CVE-2015-4852
19790693 Needs privileged block while accessing ACCESSCLASSINPACKAGE.COM.SUN.PROXY.
17968606 METHOD _JSPSERVICE exceeds limits of 65535 bytes as JSP compiler enhances the logic of the optimization that defers the JVM 64k bytes limitation in case there are a lot of JSP standard actions being used in JSP page. 
21947902 PSR: Performance PAAS optionally reduce JDBC and TLog store cached CONN from 2 to 0
22248079 CVE-2016-0577
22049932 CVE-2016-3416
20432957 Fixed an issue where a JMS NameNotFoundException occurs as a result of a mis-configuration re-targeting
22100830 JDBC TLog timeout before TLog Fail not honored.
20220959 Inject annotation doesn't work at Default Interceptor defined at ejb-jar.xml.
19947189 CVE-2016-3445
20783846 NameAlreadyBoundException while deploying application on WLS 12.1.3 
20551651 Fixed window for deadlock during automatic rollback.
22999996 rt.jar provides repackaged org.apache classes like com.sun.org.apache.*, these classes can be loaded from child classloader when prefer-web-inf-classes is true.
22666897 CVE-2016-3505
20671165 REGISTRYDOCUMENTBUILDERFACTORY DROPS PARSER FEATURES
22759067 SNI servlet invocation throws a hostname verification error and fetches the wrong SSL certificate while using WebLogic Server HTTP connection.
20256190 Fixed an issue where an application-scoped work manager was not being recognized by the console
19721047 Fixed an issue where Queue forwarding failed after JMS was restarted and continued to log "destination not found' errors
24828619 Fixed an issue where an OutOfMemory can occur when creating many JMX connections
22083678 Fixed a memory leak in WeldInjectionContainer that was evident in stress testing
24817968 CVE-2017-10063
25743025 CVE-2017-10148
25823774 CVE-2017-10178
21748022 Fixed an OutOfMemmory condition that could occur with a restart-in-place migration
25375968 Fixed an issue where resource injection of destination without JNDI name failed to deploy
25522149 Fixed an issue where clicking the webservice test line in production mode would throw an MalformedURLException
25355394 Fixed an IIOP ClassCastException that occurred after a managed server restart when an IIOP application was deployed
26563889 Fixed an issue where using wlst offline create groupparams returned an unusable cmo
25987400 Fixed an issue where it wasn't possible to provide indirect transaction propagation between servers that are on different networks
27417245 CVE-2018-2894
27934864 CVE-2018-2998
27988175 CVE-2018-3191
28140800 Bypass version string checks when non-Oracle JDK is used.

9 Known Issues
------------
For information about OPatch issues, see the following:

Doc ID 1587524.1 Using OUI NextGen OPatch 13 for Oracle Fusion Middleware 12c (12.1.2+)
https://support.oracle.com/rs?type=doc&id=1587524.1

For issues documented after the release of this WLS Patch Set Update, see the following:

Doc ID 2350415.1 Known Issues for Oracle WebLogic Server (OWLS) 12.2.1.3.X Patch Set Updates
https://support.oracle.com/rs?type=doc&id=2350415.1

If you are running with a security manager and experience
java.io.SerializablePermission "serialFilter" permission exceptions, then you
will need to update the weblogic policy file to include the following line:

    permission java.io.SerializablePermission "serialFilter";

in the coherence.jar section of the weblogic policy file:

   grant codeBase "file:@WL_HOME/../coherence/lib/coherence.jar" {

Note:  If your deployed application uses Java deserialization you may need to 
customize the WebLogic JEP 290 Default Filter.  For further information, 
refer to the "Restrict incoming serialization data." line in the Securing 
Network Connections table at 
https://docs.oracle.com/middleware/1213/wls/LOCKD/practices.htm#i1128495 

-----------------------------------------------------------------------------
DISCLAIMER:

This interim patch has only undergone basic unit testing, and has not been
through a complete test cycle generally followed for a production patch set.
Though the fixes in this document rectifies the bug, Oracle Corporation will
not be responsible for other issues that may arise due to these fixes.
Oracle Corporation recommends to later upgrade to the next production patch
set, when available. Applying this patch could overwrite other interim
patches applied since the last patch set. Customers need to make a request
to Oracle Support for a patch that includes those fixes, as well as inform
Oracle Support about all the patches installed when a Service Request is
opened. Please download, test, and provide feedback as soon as possible
to assist in the timely resolution of this problem.

Copyright (c)  2018, Oracle and/or its affiliates. All rights reserved.
----------------------------------------------------------------------------- 
