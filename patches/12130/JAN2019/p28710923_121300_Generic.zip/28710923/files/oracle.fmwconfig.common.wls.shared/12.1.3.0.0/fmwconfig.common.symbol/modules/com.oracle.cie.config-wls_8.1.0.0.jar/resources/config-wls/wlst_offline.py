import sys
import com.oracle.cie.domain.script.jython.WLScriptContext as wlctx
import os
import jarray
from java.lang import *
from javax.management import *
import javax.management.ObjectName as ObjectName

myps1="wls:/offline>"
WLS = wlctx()
cmo = None
hideProm = "false"
recording = "false"
exitonerror = "true"
oldhook = sys.displayhook
WLSTPrompt = "true"

def readTemplate(templateFileName, topologyProfile=None):
  WLS.readTemplate(templateFileName, topologyProfile)
  updateCmo()
  updatePrompt()
def cd(mbeanName):
  aCmo = WLS.cd(mbeanName)
  updateCmo()
  updatePrompt()
  hideDisplay()
  return aCmo
def prompt(myPrompt="xx"):
  global hideProm, WLSTPrompt, myps1
  if myPrompt=="off":
    WLSTPrompt="false"
    updatePrompt()
  elif myPrompt=="on":
    WLSTPrompt="true"
    updatePrompt()
  else:
    WLSTPrompt="true"
    if hideProm=="false":
      hideProm="true"
    elif hideProm == "true":
      hideProm = "false"
    updatePrompt()

def dumpStack():
  return WLS.dumpStack()
def set(attrName, value):
  WLS.set(attrName,value)
  if attrName=="Name":
    updatePrompt()

def setOption(optionName, value):
  WLS.setOption(optionName, value)
def ls(attrName="x", returnMap="false",returnType="c"):
  obj = WLS.ls(attrName, returnMap, returnType)
  hideDisplay()
  return obj
def get(attrName):
  getObj = WLS.get(attrName)
  return getObj
def delete(name, type):
  WLS.delete(name, type)
def assign(srcType, srcName, destType, destName):
  WLS.assign(srcType, srcName, destType, destName)
def unassign(srcType, srcName, destType, destName):
  WLS.unassign(srcType, srcName, destType, destName)
def assignAll(srcType, destType, destName):
  WLS.assignAll(srcType, destType, destName)
def unassignAll(srcType, destType, destName):
  WLS.unassignAll(srcType, destType, destName)
def validateConfig(optionName):
  WLS.validateConfig(optionName)
def writeDomain(domainDir):
  WLS.writeDomain(domainDir)
  updatePrompt()
def writeTemplate(templateName, timeout=120000):
  if isConnected() == 'true':
    _previousTree_ = currentTree()
    domainConfig()
    if WLS.isOnlineConfigHelperAvailable(mbs):
      WLS.writeTemplate(mbs, templateName, timeout)
      _previousTree_()
    else:
      print 'CIE ConfigHelper online service is not available.'
      _previousTree_()
  else:
    WLS.writeTemplate(templateName)
    updatePrompt()
def closeTemplate():
  global cmo, myps1
  WLS.closeTemplate()
  cmo = None
  hidePrompt = None
  myps1="wls:/offline>"
def readDomain(domainDir):
  WLS.readDomain(domainDir)
  updateCmo()
  updatePrompt()
def storeKeyStorePassword(domainTemplate,password):
  WLS.storeKeyStorePassword(domainTemplate,password)
def addTemplate(templateFile):
  WLS.addTemplate(templateFile)
def updateDomain():
  WLS.updateDomain()
def closeDomain():
  global cmo, myps1
  WLS.closeDomain()
  cmo = None
  hidePrompt = None
  myps1="wls:/offline>"
def createDomain(domainTemplate, domainDir, user, password, topologyProfile=None, nmUser='NONE', nmPassword='NONE'):
  if nmUser=="NONE" and nmPassword=="NONE":
    return WLS.createDomain(domainTemplate, domainDir, user, password, topologyProfile)
  else:
    return WLS.createDomain(domainTemplate, domainDir, user, password, topologyProfile, nmUser, nmPassword)
def pwd():
  pwdStr = WLS.getAbsPwd()
  return pwdStr
def find(name="NONE", type="NONE", searchInstancesOnly="false"):
    return WLS.find(name,type,searchInstancesOnly)
def loadDB(DBVersion, ConnectionPoolName, DBCategory=None):
  WLS.loadDB(DBVersion, ConnectionPoolName, DBCategory)
def retrieveObject(objectKey):
  return WLS.retrieveObject(objectKey)
def storeObject(key, value):
  WLS.storeObject(key, value)
def getLog():
  return WLS.getLog()
def startRecording(fileName):
  global recording
  WLS.startRecording(fileName)
def stopRecording():
  global recording
  WLS.stopRecording()
def dumpVariables():
  WLS.dumpVariables()
def exit():
  if recording=="true":
    WLS.stopRecording()

def create(name, type, baseType="NONE"):
  if baseType=="NONE":
    return WLS.create(name,type)
  else:
    return WLS.create(name,type,baseType)
def clone(origName,cloneName,type):
  return WLS.clone(origName,cloneName,type)    
def updateCmo():
  global cmo
  cmo = WLS.getCmo()
def updatePrompt():
  global hidePrompt, WLSTPrompt, myps1
  if WLSTPrompt == "false":
    myps1=sys.ps1
    return
  if hideProm == "false":
    myps1="wls:/offline"+WLS.getAbsPwd()+">"
  elif hideProm == "true":
    myps1="wls:/offline>"

def hideDisplay():
  sys.displayhook=eatdisplay
def eatdisplay(dummy):
  pass
def restoreDisplay():
  global oldhook
  sys.displayhook=oldhook
def writeIniFile(filePath):
  WLS.writeIniFile(filePath)
def setDistDestType(resName,destType):
  WLS.setDistDestType(resName,destType)
def getTopologyProfile():
  return WLS.getTopologyProfile()
def listServerGroups(printOutput="false"):
  return WLS.listServerGroups(printOutput)
def getServerGroups(serverName, timeout=120000):
  if isConnected() == 'true':
    _previousTree_ = currentTree()
    domainConfig()
    _svrGroups_ = WLS.getServerGroupsOnline(mbs, serverName, timeout)
    _previousTree_()
    return _svrGroups_
  else:
    return WLS.getServerGroups(serverName)
def setServerGroups(serverName, serverGroups, timeout=120000, skipEdit='true'):
  if serverGroups == None:
    serverGroups = []
  if isConnected() == 'false':
    WLS.setServerGroups(serverName, serverGroups)
  else:
    _previousTree_ = currentTree()
    domainConfig()
    WLS.setServerGroupsOnline(mbs, serverName, serverGroups, timeout)
    _previousTree_()
    editServiceMBean = ObjectName('com.bea:Name=EditService,Type=weblogic.management.mbeanservers.edit.EditServiceMBean')
    print 'Reloading configuration changes'
    configManagerMBean = mbs.getAttribute(editServiceMBean, 'ConfigurationManager')
    params = []
    signature = []
    mbs.invoke(configManagerMBean, "reload", params, signature);
def addStartupGroup(startupGroupName, serverGroupName):
  WLS.addStartupGroup(startupGroupName, serverGroupName)
def deleteStartupGroup(startupGroupName):
  WLS.deleteStartupGroup(startupGroupName)
def setStartupGroup(serverName, startupGroupName):
  WLS.setStartupGroup(serverName, startupGroupName)
def getStartupGroup(serverName):
  return WLS.getStartupGroup(serverName)
def getNodeManagerHome():
  return WLS.getNodeManagerHome()
def getNodeManagerType():
  return WLS.getNodeManagerType()
def getOldNodeManagerHome():
  return WLS.getOldNodeManagerHome()
def getNodeManagerUpgradeType():
  return WLS.getNodeManagerUpgradeType()
def getNodeManagerUpgradeOverwriteDefault():
  return WLS.getNodeManagerUpgradeOverwriteDefault()  
def getDatabaseDefaults(connection=None):
  return WLS.getDatabaseDefaults(connection)
def readDomainForUpgrade(domainName, properties=None):
  WLS.readDomainForUpgrade(domainName, properties)
  updateCmo()
  updatePrompt()
def isConnected():
  isConnected = 'false'
  try:
    isConnected = connected
  except NameError:
    isConnected = 'false'
  return isConnected
def setSharedSecretStoreWithPassword(sharedSecretStore,secretStorePassword):
  WLS.setSharedSecretStoreWithPassword(sharedSecretStore, secretStorePassword)
def createServiceTable():
  return WLS.createServiceTable()
def createServiceTableEndPoint(serviceid, servicetype): 
  return WLS.createServiceTableEndPoint(serviceid, servicetype)
def createServiceTableEndPointConnection():
  return WLS.createServiceTableEndPointConnection()
def createServiceTableJaxWSPolicy(policyName):
  return WLS.createServiceTableJaxWSPolicy(policyName)
def createServiceTableT3Policy(policyName):
  return WLS.createServiceTableT3Policy(policyName)
def createDBDefaultsConnection():
  return WLS.createDBDefaultsConnection()
def setFEHostURL(plain, ssl, isPlainDefault="true"):
  WLS.setFEHostURL(plain, ssl, isPlainDefault)
def deleteFEHost():
  WLS.deleteFEHost()
def getFEHostURL(urltype):
  return WLS.getFEHostURL(urltype);
def unSet(attrName):
   WLS.unSet(attrName)
def isSet(attrName):
   return WLS.isSet(attrName)
