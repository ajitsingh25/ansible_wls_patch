/*
  This script revokes privilege requested by bug23056582. It also revokes
  additional privilege that are not used.
*/ 
revoke create type from &1;
revoke create any index from &1;
revoke create any trigger from &1;
revoke create sequence from &1;
revoke create procedure from &1;
